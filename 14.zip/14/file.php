<?php

require_once "baza.php";


$rezultat = $baza->query("SELECT * FROM korisnici");

$korisnici = $rezultat->fetch_all(MYSQLI_ASSOC);




//-------------------------------------------------------



$product_search = $baza->query("SELECT * FROM proizvodi");

$products = $product_search->fetch_all(MYSQLI_ASSOC);

foreach($products as $product)
{
    echo $product['cena'] ; 
}



?>