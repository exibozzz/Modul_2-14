<?php


    $baza = mysqli_connect("localhost", "root", "", "baza");


    $name_lastname = $_POST['nameLastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $birthday = $_POST['birthday'];

    //--------------------------------------

            if(!isset($_POST['nameLastName']) || empty($_POST['nameLastName']) )
            {
              die("You have not entered name.");
            }


            if(!isset($_POST['email']) || empty($_POST['email']) )
            {
              die("You have not entered email.");
            }


            if(!isset($_POST['password']) || empty($_POST['password']) )
            {
              die("You have not entered password.");
            }


            if(!isset($_POST['birthday']) || empty($_POST['birthday']) )
            {
              die("You have not entered birthday.");
            }

    //--------------------------------------

    $insert_data = $baza->query("INSERT INTO korisnici (ime_prezime, email, lozinka, datum_rodjenja) VALUES ('$name_lastname','$email','$password', '$birthday')");




?>