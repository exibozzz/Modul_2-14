<?php

$baza = mysqli_connect("localhost","root","","baza");


?>